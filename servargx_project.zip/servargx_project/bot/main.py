from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, ContextTypes
from handlers import files, subscriptions, admin
from keyboards.main_buttons import main_menu
from config import BOT_TOKEN, WELCOME_IMAGE

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_photo(
        photo=open(WELCOME_IMAGE, "rb"),
        caption="مرحبًا بك في ServarGX!\nاختر الخيار الذي تريد من الأزرار أدناه."
    , reply_markup=main_menu())

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data

    if data == "upload_file":
        await files.upload_file(update, context)
    elif data == "my_files":
        await files.my_files(update, context)
    elif data == "plans":
        await subscriptions.show_plans(update, context)
    elif data == "ping":
        await query.message.reply_text("💨 سرعة البوت ممتازة!")
    elif data == "main_menu":
        await query.message.reply_text("📌 القائمة الرئيسية:", reply_markup=main_menu())
    await query.answer()

if __name__ == "__main__":
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(handle_callback))
    app.run_polling()