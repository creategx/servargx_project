from telegram import Update
from telegram.ext import ContextTypes

PLANS_INFO = {
    "free": "🟢 الاشتراك المجاني:\n- رفع 10 ملفات فقط\n- تشغيل 9 ساعات يومياً",
    "pro": "🔵 اشتراك Pro:\n- رفع 100 ملف\n- تشغيل 12 ساعة\n- مزايا أقوى",
    "max": "🔴 اشتراك Max:\n- رفع غير محدود\n- تشغيل دائم\n- إضافة/حذف مستخدمي Pro"
}

async def show_plans(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = "\n\n".join(PLANS_INFO.values())
    await update.callback_query.message.reply_text(msg)