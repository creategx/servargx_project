import os
from telegram import Update
from telegram.ext import ContextTypes
from ..config import STORAGE_PATH
from ..keyboards.file_buttons import file_options

async def upload_file(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.message.reply_text(
        "📤 أرسل لي الملف الذي تريد رفعه."
    )

async def my_files(update: Update, context: ContextTypes.DEFAULT_TYPE):
    files = os.listdir(STORAGE_PATH)
    if not files:
        await update.callback_query.message.reply_text("📂 لم يتم رفع أي ملفات بعد.")
        return

    for file in files:
        await update.callback_query.message.reply_text(
            f"📄 {file}", reply_markup=file_options(file)
        )