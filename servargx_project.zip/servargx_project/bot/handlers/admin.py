from telegram import Update
from telegram.ext import ContextTypes
from ..config import ADMIN_ID

async def admin_only(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id != ADMIN_ID:
        await update.message.reply_text("🚫 لا تملك صلاحية الوصول.")
        return False
    return True