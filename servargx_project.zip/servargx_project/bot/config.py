# إعدادات البوت
BOT_TOKEN = "8300946367:AAG3Q0QVHB3-dCciQqjzMBse5tZT33a0E5I"
ADMIN_ID = 6629208382
ADMIN_USERNAME = "@NK_QA"

# مسارات التخزين
STORAGE_PATH = "../storage/"

# الاشتراكات
PLANS = {
    "free": {
        "max_files": 10,
        "runtime_hours": 9
    },
    "pro": {
        "max_files": 100,
        "runtime_hours": 12
    },
    "max": {
        "max_files": 9999,
        "runtime_hours": 24
    }
}

# الصورة الترحيبية
WELCOME_IMAGE = "../assets/welcome.jpg"