from telegram import InlineKeyboardButton, InlineKeyboardMarkup

def file_options(file_name):
    keyboard = [
        [
            InlineKeyboardButton("▶️ تشغيل", callback_data=f"run_{file_name}"),
            InlineKeyboardButton("⏸ إيقاف", callback_data=f"stop_{file_name}"),
            InlineKeyboardButton("🗑 حذف", callback_data=f"delete_{file_name}")
        ],
        [
            InlineKeyboardButton("🔙 رجوع", callback_data="main_menu")
        ]
    ]
    return InlineKeyboardMarkup(keyboard)