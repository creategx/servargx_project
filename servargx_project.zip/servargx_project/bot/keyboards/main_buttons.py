from telegram import InlineKeyboardButton, InlineKeyboardMarkup

def main_menu():
    keyboard = [
        [
            InlineKeyboardButton("📤 رفع ملف", callback_data="upload_file"),
            InlineKeyboardButton("📁 ملفاتي", callback_data="my_files")
        ],
        [
            InlineKeyboardButton("💨 سرعة البوت", callback_data="ping"),
            InlineKeyboardButton("💳 الاشتراكات", callback_data="plans")
        ],
        [
            InlineKeyboardButton("ℹ️ حساب المطور", url="https://t.me/NK_QA")
        ]
    ]
    return InlineKeyboardMarkup(keyboard)